#include "BST.h"
#include <iostream>
using namespace std;

int main() {
  BST bst;



  
  bst.insert(11);
  bst.insert(15);
	bst.insert(8);
	bst.insert(4);
	bst.insert(3);
	bst.insert(6);
	bst.insert(5);
	bst.insert(7);
	bst.insert(10);
	bst.insert(9);
	bst.insert(12);
	bst.insert(20);
	bst.insert(17);
	bst.insert(25);

  cout << ("\nBefore Convert ");
  cout << ("\nIn-order Data : ");
  bst.inorder(bst.root);
  cout << ("\nPre-order Data : ");
  bst.preorder(bst.root);
  cout << ("\nPost-order Data : ");
  bst.postorder(bst.root);
  bst.maxHeap(bst.root);
  cout << ("\nAfter Convert ");
  cout << ("\nIn-order Data : ");
  bst.inorder(bst.root);
  cout << ("\nPre-order Data : ");
  bst.preorder(bst.root);
  cout << ("\nPost-order Data : ");
  bst.postorder(bst.root);
  return 0;
}