#include <iostream>
using namespace std;

class Node {
public:
	int key, Age, Salary  , workingdays , weight , bonus ;
  int  Marks;
  string Employee_Name ; // Variables for employee management system
	Node* parent;
	Node* left;
	Node* right;

	Node() { //default constructor
		key= -1, Employee_Name= "", Age= 1, Salary= -1 , Marks= -1, workingdays = 1 , weight = 0  , bonus = 0; 
		parent = NULL;
		left = NULL;
		right = NULL;
	}

	Node(int k,string Name1, int age) {
		key = k;
    Employee_Name= Name1;
    Age= age;
      Salary= -1 ;
      Marks= -1; 
      workingdays = 0 ; 
      weight = 0  ;
      bonus = 0; 
		parent = NULL;
		left = NULL;
		right = NULL;
	}
};

class BST {
public:
	Node* root;
	int size;

public:
	BST() {
		root = NULL;
		size = 0;
	}

	void insert(int k, string Name1, int age1) {
    
		Node* temp = new Node(k,Name1,age1);
		Node* current = root;
		Node* prev = NULL;

		if (root == NULL)
			root = temp;
		else {
			while (current != NULL) { //move current pointer to relavent position
				prev = current;
				if (k > current->key) {
					current = current->right;
				}
				else if (k < current->key) {
					current = current->left;
				}
				else {
					cout << "Duplicate values are not allowed" << endl;
					return;
				}
			}

			if (k > prev->key) {
				prev->right = temp;
				temp->parent = prev;
			}
			else if (k < prev->key) {
				prev->left = temp;
				temp->parent = prev;
			}
		}	
		size++;
	}

	void print() {
		Node* current = root;
    
	}

	bool search(int k) {
		if (root == NULL) {
			cout << "Tree is empty" << endl;
		}
		else {
			Node* current = root;
			while (current != NULL){
				if (current->key == k) {
					cout << "Key exists" << endl;
					return true;
				}
				else if (k < current->key) {
					current = current->left;
				}
				else if (k > current->key) {
					current = current->right;
				}
			}
			cout << "Key not found" << endl;
			return false;
		}
	}

//Age, Salary  , workingdays , weight , bonas ;
  //int  Marks;
void print_values(int k) {
		if (root == NULL) {
			cout << "Tree is empty" << endl;
		}
		else {
			Node* current = root;
			while (current != NULL){
				if (current->key == k) {
					cout << "Key exists" << endl;
					cout<<current->key<<endl<<"Name - "<<current->Employee_Name<<endl<<"Age - "<<current->Age<<endl<<"Salary - "<<current-> Salary<<endl<<"No. of Working Days - "<<current->workingdays<<endl<<"Marks within the position - "<<current-> Marks<<endl;

          break;
				}
          
				else if (k < current->key) {
					current = current->left;
				}
				else if (k > current->key) {
					current = current->right;
				}
			}
			cout << "Key not found" << endl;
		}
	}

Node* extract(int k) {
		if (root == NULL) {
			cout << "Tree is empty" << endl;
		}
		else {
			Node* current = root;
			while (current != NULL){
				if (current->key == k) {
					cout << "Key exists" << endl;
					return current;
				}
				else if (k < current->key) {
					current = current->left;
				}
				else if (k > current->key) {
					current = current->right;
				}
			}
			cout << "Key not found" << endl;
			return NULL;
		}
	}






	void deleteNode(int key) {
		if (root == NULL) {
			cout << "Tree is empty" << endl;
		}
		else {
			Node* current = root;
			//-----move current pointer to the required key-----//
			while (current != NULL && current->key != key) {
				if (key < current->key) {
					current = current->left;
				}
				else if (key > current->key) {
					current = current->right;
				}
			}

			//-----delete operations-----//
			if (current == NULL) {
				cout << "Searched key does not exists" << endl; //key does not exists
			}
			else if (current->left == NULL && current->right == NULL) { //deleting a leaf node
				if (current == root) { //delete root node
					root = NULL;
				}
				if (current->key < current->parent->key) { //delete left leaf
					current->parent->left = NULL;
				}
				else { //delete right leaf
					current->parent->right = NULL;
				}
				delete current;
				size--;
			}
			else if (current->left == NULL) { //node to be deleted has right child

				if (current == root) {
					root = current->right;
					root->parent = NULL;
				}
				if (current->key < current->parent->key) { //current is in the left of parent 
					current->parent->left = current->right;
				}
				else { //current is in the right of parent
					current->parent->right = current->right;
				}
				delete current;
				size--;
			}
			else if (current->right == NULL) { //node to be deleted has a left child
				
				if (current == root) { //if current == root, make left child the root
					root = current->left;
					root->parent = NULL;
				}
				if (current->key < current->parent->key) {
					current->parent->left = current->left;
				}
				else {
					current->parent->right = current->left;
				}
				delete current;
				size--;
			}
			else { //node has 2 children
				//Here, the node to be deleted is replaced by the max value of the tree in the left side (method 1)
				//select node with lowest val from right,, might ask in exam (method 2)

				Node* max = current->left; //take left child as the max
				while (max->right != NULL) {
					max = max->right;
				}

				current->key = max->key; //assign max->key to current->key 
				//now, key of the node to be deleted is replaced by max key of that subtree


				if (max == current->left) {
					current->left = max->left; //max dont have aright child
					if (max->left != NULL) {
						max->left->parent = current;
					}
				}
				else {
					max->parent->right = max->left;//max->right doesnt exist. no ned to check
					if (max->left != NULL) {
						max->left->parent = max->parent;
					}
				}
				delete max;
				size--;
			}
		}
	}
	void swap(Node *first, Node *second) {
        int value = first->key;
        first->key = second->key;
        second->key = value;
  }
	
	void maxHeap(Node* current) {
	    
        if (current == NULL)
            return;
        //maxHeap(current->left);
        //maxHeap(current->right);
        
        if (current->left != NULL && current->left->key > current->key) {
            swap(current, current->left);
            //cout<<"1";
            maxHeap(current);
        }
        if (current->right != NULL && current->right->key > current->key) {
            swap(current, current->right);
            maxHeap(current);
    }
  }

	void preorder(Node* node) {
		if (node != NULL) {
			cout << " | " << node->key;
			preorder(node->left);
			preorder(node->right);
			return;
		}
	}

	void inorder(Node* node) {
		if (node != NULL) {
			inorder(node->left);
			cout << " | " << node->key;
			inorder(node->right);
			return;
		}
	}

	void postorder(Node* node) {
		if (node != NULL) {
			postorder(node->left);
			postorder(node->right);
			cout << " | " << node->key;
			return;
		}
	}

	void traverse(int method) {
		switch (method) {
		case 1:
			cout << "pre order method: "; preorder(root); cout << endl;
			break;
		case 2:
			cout << "in order method: "; inorder(root); cout << endl;
			break;
		case 3:
			cout << "post order method: "; postorder(root); cout << endl;
			break;
		}
	}

int salary (int Get_ID){



    if (root == NULL) {
			cout << "Tree is empty" << endl;
      return 0;
		}
		else {
			Node* current = root;
			while (current != NULL){
				if (current->key == Get_ID) {
					cout << "Key exists" << endl;
				
          int temp_Salary = current->Salary;                 
                
                int basic = 0 ;
                if (current->key >= 17){
                  basic = 100000;
                  current->weight = 10;
                }
                else if (current->key >= 12){
                 basic = 80000;
                  current->weight = 8;
                }
                else if (current->key >= 9){
                 basic = 65000;
                  current->weight = 7;
                }
                else if (current->key >= 6){
                 basic = 40000;
                  current->weight = 6;
                }
                else {
                  basic = 20000;
                  current->weight = 3;
                }
                if (current->Marks >= 100){
                  current->bonus = 30000;
                }
                else if(current->Marks >= 75){
                  current->bonus = 22500;
                }
                else if (current->Marks >= 50){
                  current->bonus = 15000;
                }
                else if (current->Marks >= 35) {
                  current->bonus = 5000;
                }
                else {
                  current->bonus = 0;
                }
               temp_Salary =  basic + 100 * current->workingdays * current->weight + current->bonus ;

          current->Salary=temp_Salary;
                  return temp_Salary;}
                  
              


  

        
          
				

      
				else if (Get_ID < current->key) {
					current = current->left;
				}
				else if (Get_ID > current->key) {
					current = current->right;
				}
  }
			cout << "Key not found" << endl;
      }
      return 0;
		}


  
  

int marks (int Get_ID,int addmarks ) {
 /* if(Get_ID>300){
    //300 states that the marks adding acess is only available for managers and higher posts */
  //Node*temp;
  //temp= extract(Get_ID);
  
  //temp->right =NULL;
  //temp->left =NULL;
  //temp->key= extract(Get_ID)->key;

  int temp_marks;
    
    if (root == NULL) {
     
			cout << "Tree is empty" << endl;
      return 0;
		}
		else {
      
			Node* current = root;
			while (current != NULL){

        static int y =0;
        
				if (current->key == Get_ID) {
					cout << "Key exists" << endl;
					temp_marks = current->Marks;
          //cout<<temp_marks+1;
          
           
              //cin >> addmarks ; 
              temp_marks += addmarks; 
              current->Marks= temp_marks;
            return temp_marks ;


          
				}

          
				else if (Get_ID < current->key) {
					current = current->left;
				}
				else if (Get_ID > current->key) {
					current = current->right;
				}
        
          if(y==0){
           if (temp_marks >= 100){
              cout << "Rewarded"<< endl;
            }
          else {
              cout << "Warning..." << endl; 
            }
            }

        y++;

        
			}
			cout << "Key not found" << endl;
    
			temp_marks = 0;
     
      return 0;
		}

  }









 /* else {
    cout << "You are not supported to add marks";
    return

  }*/
  
int check_marks (int Get_ID){
  
    return marks(Get_ID,0);
  }
 


  


};

